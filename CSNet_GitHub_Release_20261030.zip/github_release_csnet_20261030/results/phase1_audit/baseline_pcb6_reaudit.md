# PCB6 基线结果复审与论文修改方案

审计日期：2026-10-10  
审计方式：只读检查训练代码、checkpoint、PCB6 统一评测代码及实际结果文件；未修改任何既有代码、数据、权重或论文。

## 1. 纠正后的结论

3D U-Net、UNETR 和旧版 Swin-UNETR 已经在新 PCB6 独立测试集上完成统一复测。`outputs/unified_200_test/unified_results.json` 记录了 2026-09-23 的推理运行：200 个样本、RTX 3090 Ti、PyTorch 2.5.1+cu121，且明确加载了三个旧基线 checkpoint 和正式 CS-Net L1 checkpoint。因此，这些基线的 PCB6 重建指标可以进入论文，上一版“旧基线尚未在 PCB6 复测”的判断应撤回。

但需要区分两个层次：

1. **PCB6 测试来源清楚**：每种方法均有 200 行逐样本 CSV、汇总 JSON、checkpoint 路径和统一评测代码。
2. **旧基线训练来源不完整**：3D U-Net、UNETR、旧 Swin-UNETR checkpoint 只是纯 `state_dict`，未保存训练 epoch、最佳验证损失、优化器、调度器、随机状态和配置快照。其训练脚本也未设置随机种子。因此可以准确说明网络结构、数据目录和主要超参数，但不能声称训练随机种子为 20260916，也不能从 checkpoint 单独恢复出最佳 epoch。

## 2. 准确的数据来源

### 2.1 训练与模型选择数据

三个旧基线训练脚本分别为：

- `train_3d_unet_baseline.py`
- `train_unetr_baseline.py`
- `train_3d_swin_unetr.py`

它们实际读取：

| 角色 | Dirty 路径 | GT 路径 | 实际 RAW 数 | PCB |
|---|---|---|---:|---|
| 训练 | `G:\CT_RE\dataset\Final_Adaptive_Dirty\train` | `G:\CT_RE\dataset\Final_Adaptive_GT\train` | 2,098 对 | PCB 1–4 |
| 验证（脚本变量名仍为 test） | `G:\CT_RE\dataset\Final_Adaptive_Dirty\test` | `G:\CT_RE\dataset\Final_Adaptive_GT\test` | 432 对 | PCB 5 |

所有旧基线均使用 float32、`40×256×256` 输入，Z 向反射填充为 64 层，输出裁切 `12:52`，只在真实 40 层上计算 L1 损失；优化器为 AdamW，初始学习率 `1e-4`、权重衰减 `1e-4`，CosineAnnealingLR，训练 100 epoch，启用 AMP。

批量大小并不完全相同：3D U-Net 为 4，UNETR 为 1，旧 Swin-UNETR 为 2。三个脚本均未固定 Python/NumPy/PyTorch 随机种子。因此论文不能写“所有训练条件完全一致”，应写成“数据、损失、优化器、学习率、训练轮数及预处理一致；批量大小按模型显存需求设置”。

### 2.2 训练集生成来源的可复现性缺口

`build_full_dataset.py` 当前配置一次运行应为 PCB 1–4 各 250 个训练 patch、PCB 5 为 200 个验证 patch。但实际目录包含 2,098 个训练文件和 432 个验证文件：同一 `board+patch编号` 下保留了多个尺度文件。

| 分区 | 唯一逻辑 patch 编号 | 实际文件数 | 多出的尺度变体 |
|---|---:|---:|---:|
| train | 1,000 | 2,098 | 1,098 |
| validation | 200 | 432 | 232 |

原因可由命名及生成逻辑解释：文件名包含随机选择的 `scale1x/2x/4x`，生成脚本没有先清空目录；重复运行时，不同尺度文件会并存。旧脚本没有固定裁切随机种子，也没有为 PCB 1–5 保存裁切坐标 manifest。故论文应以**训练时实际加载的 2,098/432 对文件**报告样本数，但不能声称该旧训练集可由当前脚本和某个已知随机种子逐文件重建。

这一问题不构成 PCB 级泄漏：训练来自 PCB 1–4，验证来自 PCB 5，独立测试来自 PCB 6；但它属于训练数据 provenance 和复现性限制，应在方法或补充材料中如实说明。

### 2.3 PCB6 独立测试集

独立测试路径：

- Dirty：`G:\CT_RE\dataset\Final_Adaptive_Dirty\independent_test`
- GT：`G:\CT_RE\dataset\Final_Adaptive_GT\independent_test`

数据由 `build_independent_testset.py` 从 `G:\CT_RE\PCB\6` 的 `t6.png/b6.png/d6.png/s6.png` 生成，随机种子为 20260916。共 200 对 float32 RAW，单体尺寸 `40×256×256`；尺度分布为 1× 53 个、2× 68 个、4× 79 个。每个文件 10,485,760 字节。`manifest.csv` 保存尺度和裁切坐标，`dataset_info.txt` 保存板号、源图和种子。

Dirty 数据经 `simulate_cl_dirty_data.py` 生成：180 投影、45° CL 倾角、Poisson `I0=5e4`、30 次 `SIRT3D_CUDA`。PCB6 未被任何训练或验证脚本加载。

### 2.4 PCB6 统一评测来源

统一评测入口为 `unified_evaluate_200.py`。它对所有学习方法执行相同的：

- PCB6 的 200 个配对样本；
- Z 向反射填充 12+12 层；
- 输出裁切回 40 层；
- 预测裁剪到 `[0,1]`；
- RMSE、PSNR、3D SSIM、三轴 Gradient MAE、铜区域 Dice/IoU。

铜指标不是任意灰度阈值：GT 生成器将铜赋值为 1.00、次高材料锡膏赋值为 0.82，GT 铜掩膜使用 `abs(GT-1.0)<=1e-6`，预测阈值 0.91 是二者中点。

## 3. Checkpoint 来源

| 模型 | PCB6 评测加载权重 | SHA-256 | 可追溯程度 |
|---|---|---|---|
| 3D U-Net | `checkpoints/3d_unet_best.pth` | `c115a46e...7265fc0` | 纯 state_dict；结构与训练脚本一致，无 epoch/随机状态 |
| UNETR | `checkpoints/unetr_baseline_best.pth` | `2983df92...a0a626` | 纯 state_dict；可严格加载，无 epoch/随机状态 |
| 旧 Swin-UNETR | `checkpoints/swin_unetr_best.pth` | `6204c405...97701` | 纯 state_dict；不是正式消融 A 的 checkpoint |
| 正式 CS-Net L1 | `outputs/ablation/csnet_l1/seed_20260916/best_val.pt` | `90d8a597...9af3d` | 完整 checkpoint，含 epoch、优化器、调度器、AMP、随机状态与配置摘要 |

UNETR 存在必须在论文外部记录中说明的命名不一致：当前 `train_unetr_baseline.py` 写出的名字是 `unetr_baseline_best2.pth`，但该文件目前不存在；PCB6 统一评测实际加载的是 `unetr_baseline_best.pth`。该权重能被当前 UNETR 定义严格加载并完成 200 个样本推理，因此数值有效，但仅凭现存文件无法证明它由当前脚本的哪一版本、哪一个最佳 epoch 写出。

## 4. PCB6 正式数值应如何取用

### 4.1 主方法对比表

建议主表的数据来源固定为：

| 方法 | 采用结果 | 原因 |
|---|---|---|
| FDK | `outputs/unified_200_test/fdk_summary.json` | PCB6 统一评测 |
| SIRT | `outputs/unified_200_test/sirt_summary.json` | PCB6 paired dirty 输入本身 |
| 3D U-Net | `outputs/unified_200_test/3d_u_net_summary.json` | 已在 PCB6 统一复测 |
| UNETR | `outputs/unified_200_test/unetr_summary.json` | 已在 PCB6 统一复测 |
| Swin-UNETR | 正式 A 组 `outputs/ablation/swin_unetr_baseline/seed_20260916/test_results.json` | 与 D 同一受控框架，适合 A vs D |
| CS-Net | 正式 D 组 `outputs/ablation/csnet_l1/seed_20260916/test_results.json` | 完整 L1 方法 |

不要在主表采用 `unified_200_test/swin_unetr_summary.json` 的旧 Swin checkpoint，同时又在消融表采用正式 A 组。两者都是 PCB6 结果，但来自不同训练运行，会造成同名模型出现两套数值。

按上述来源，推荐主结果为：

| 方法 | RMSE↓ | PSNR↑ | SSIM↑ | Gradient MAE↓ | Dice↑ | IoU↑ |
|---|---:|---:|---:|---:|---:|---:|
| FDK | 0.33740 | 9.4556 | 0.24935 | 0.046903 | 0.00023 | 0.00012 |
| SIRT | 0.43280 | 7.3753 | 0.23770 | 0.040394 | 0.00004 | 0.00002 |
| 3D U-Net | 0.05914 | 25.0927 | 0.96261 | 0.007459 | 0.95024 | 0.90653 |
| UNETR | 0.03870 | 28.7789 | 0.98381 | 0.001982 | 0.99096 | 0.98213 |
| Swin-UNETR（正式 A） | 0.03858 | 28.8847 | 0.98627 | **0.001872** | 0.99136 | 0.98291 |
| CS-Net（正式 D） | **0.03756** | **29.1347** | **0.98667** | 0.001964 | **0.99166** | **0.98351** |

准确结论是：CS-Net 在 RMSE、PSNR、SSIM、Dice 和 IoU 上取得最佳均值，并显著降低相对 Swin-UNETR 的计算开销；Swin-UNETR A 的 Gradient MAE 更低。因此必须删除“CS-Net 六项指标全部最优”的表述，改为“CS-Net 在五项指标上最优，并取得最佳综合精度—效率权衡；Gradient MAE 略逊于正式 Swin-UNETR 基线”。

### 4.2 消融表

消融表只使用统一消融框架 A–E，不混入旧 checkpoint：

- A vs D：正式 Swin-UNETR 与完整 CS-Net；
- B vs D：空间压缩；
- C vs D：HR skip；
- D vs E：L1 与 MSE。

### 4.3 效率表

正式 A–E 的 Params、FLOPs、VRAM、时间来自 50 次预热 + 100 次计时，可直接用于消融效率表。

`unified_evaluate_200.py` 中 3D U-Net、UNETR 和旧 Swin 的时间是逐样本单次前向统计，没有 50 次预热，其口径与正式 A–E 不同。它们不能直接进入同一正式效率表。已核算参数量：3D U-Net 4,805,534；UNETR 121,743,569；正式 A 15,702,979；D 15,775,507。若论文需要六方法效率对比，必须用同一 benchmark 入口重新测量 3D U-Net 和 UNETR 的 FLOPs、峰值显存及 50+100 推理时间；无需重新训练。

## 5. 论文修改步骤

1. **修改数据划分描述**：明确 PCB 1–4/PCB 5/PCB 6 分别为训练、验证和独立测试；报告实际加载数量 2,098/432/200。
2. **增加多尺度旧数据说明**：训练与验证目录包含同一逻辑 patch 编号的不同尺度实现；旧数据无裁切 manifest 和固定生成种子，将其列为复现性限制。
3. **整体替换主结果表**：使用本报告 4.1 的唯一来源，不再使用初稿旧表数字。
4. **分离主表与消融表**：主表使用 3D U-Net、UNETR、正式 A、正式 D；消融表严格使用 A–E。
5. **校准主结论**：写成 CS-Net 五项质量指标最优、Gradient MAE 略逊于 A，但以约 44.06% FLOPs、74.61% 峰值显存和 63.72% 推理时间降幅获得更好的综合权衡。
6. **校准 L1 结论**：L1 更利于结构保持；MSE 的 RMSE/PSNR 更优，不能写 L1 全面优于 MSE。
7. **补齐效率数据**：仅需重新 benchmark 3D U-Net 和 UNETR，不需要重新训练或重新跑 200 样本质量评价。
8. **增加 provenance 限制**：说明旧基线 checkpoint 为纯 state_dict、训练种子和最佳 epoch无法从权重恢复；UNETR 当前脚本文件名与实测权重名不一致。
9. **统计措辞**：表中的 `mean±std` 是 PCB6 的 200 个样本间统计量，不是多随机种子训练统计；目前不能使用“统计显著”或“稳定优于”等措辞。

## 6. 当前证据等级

- PCB6 文件配对、样本数、指标与逐样本结果：**充分**。
- 3D U-Net/UNETR 在 PCB6 上的测试事实：**充分**。
- 正式 A–E 的训练与 checkpoint provenance：**充分**。
- 旧 3D U-Net/UNETR/Swin 的网络结构和主要训练超参数：**可由代码支持**。
- 旧基线的训练随机种子、最佳 epoch、完整恢复状态：**无法由现有 checkpoint证明**。
- 旧训练集逐 patch 的原始裁切坐标与唯一生成过程：**无法由现有文件完全恢复**。

