# C vs D multi-seed comparison

C removes the high-resolution structural skip; D is the complete CS-Net. Both use L1.
Each board contains 200 paired samples. Predictions are averaged per sample over seeds 20260916/17/18 before paired testing.

| PCB | Metric | C mean | D mean | D-oriented improvement | Relative improvement | 95% CI | Holm p |
|---:|---|---:|---:|---:|---:|---:|---:|
| 6 | rmse | 0.03735061 | 0.03733560 | 0.00001501 | 0.04% | [-0.00018679, 0.00019968] | 0.177 |
| 6 | psnr | 29.16913334 | 29.19367383 | 0.02454050 | 0.08% | [-0.04051182, 0.09599807] | 0.127 |
| 6 | ssim | 0.98607875 | 0.98669459 | 0.00061584 | 0.06% | [0.00047535, 0.00076334] | 1.36e-14 |
| 6 | gradient_mae | 0.00226489 | 0.00194871 | 0.00031618 | 13.96% | [0.00027930, 0.00035431] | 5.73e-33 |
| 6 | copper_dice | 0.99057628 | 0.99184563 | 0.00126935 | 0.13% | [0.00109178, 0.00145649] | 5.11e-30 |
| 6 | copper_iou | 0.98139888 | 0.98387003 | 0.00247116 | 0.25% | [0.00212855, 0.00281996] | 5.11e-30 |
| 7 | rmse | 0.05083094 | 0.05115163 | -0.00032069 | -0.63% | [-0.00055432, -0.00009101] | 0.194 |
| 7 | psnr | 26.32262723 | 26.23856145 | -0.08406578 | -0.32% | [-0.13501436, -0.03282758] | 0.127 |
| 7 | ssim | 0.97214848 | 0.97262618 | 0.00047770 | 0.05% | [0.00024335, 0.00070227] | 9.84e-05 |
| 7 | gradient_mae | 0.00304067 | 0.00281189 | 0.00022878 | 7.52% | [0.00019757, 0.00026102] | 1.17e-26 |
| 7 | copper_dice | 0.98482149 | 0.98551989 | 0.00069840 | 0.07% | [0.00048303, 0.00092474] | 2.43e-09 |
| 7 | copper_iou | 0.97022568 | 0.97156142 | 0.00133574 | 0.14% | [0.00092408, 0.00176855] | 2.43e-09 |
| 8 | rmse | 0.04210008 | 0.04276040 | -0.00066031 | -1.57% | [-0.00127642, -0.00008232] | 1 |
| 8 | psnr | 27.91879355 | 27.82194869 | -0.09684485 | -0.35% | [-0.20310866, 0.00040374] | 1 |
| 8 | ssim | 0.98017086 | 0.97924111 | -0.00092975 | -0.09% | [-0.00151530, -0.00040154] | 0.953 |
| 8 | gradient_mae | 0.00188591 | 0.00174493 | 0.00014099 | 7.48% | [0.00010140, 0.00017740] | 1.4e-16 |
| 8 | copper_dice | 0.98186424 | 0.98138403 | -0.00048021 | -0.05% | [-0.00160193, 0.00046130] | 0.0117 |
| 8 | copper_iou | 0.96532280 | 0.96480448 | -0.00051833 | -0.05% | [-0.00226880, 0.00100721] | 0.0117 |

## Structural conclusion

- PCB6: HR skip changes Gradient MAE from 0.002265 to 0.001949 (13.96% D-oriented improvement), SSIM from 0.986079 to 0.986695, and Dice from 0.990576 to 0.991846.
- PCB7: HR skip changes Gradient MAE from 0.003041 to 0.002812 (7.52% D-oriented improvement), SSIM from 0.972148 to 0.972626, and Dice from 0.984821 to 0.985520.
- PCB8: HR skip changes Gradient MAE from 0.001886 to 0.001745 (7.48% D-oriented improvement), SSIM from 0.980171 to 0.979241, and Dice from 0.981864 to 0.981384.

The primary claim should be based on Gradient MAE and local structural metrics. A small PSNR trade-off does not negate the skip's structural contribution.
